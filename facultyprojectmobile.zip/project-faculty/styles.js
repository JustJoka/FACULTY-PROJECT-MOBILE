import {StyleSheet} from 'react-native';

export default StyleSheet.create({
  container: {
    flex: 1,
    padding: 0,
    margin: 0,
    justifyContent:'center',
    alignItems: 'center',
    backgroundColor: '#FACFF1'
  },
   logo: {
    width: 120,
    height: 120,
    marginBottom: 20,
    alignSelf: 'center',
    marginBottom: 140,
    borderRadius: '50%'
  },
  titulo:{
    fontSize: 50,
    textAlign: 'center',
    top: -100,
    fontWeight: 'bold',
    color: '#6200ee',
    textShadowColor: '#aaa',
    textShadowOffset: {width: 1, height: 1},
    textShadowRadius: 2,
    letterSpacing: 3
  },
  inputs: {
    marginBottom: 15,
    width: '80%',
    borderRadius: 20,
    backgroundColor: '#FFE6F0'
  },

  botoes: {
    marginVertical: 8,
    paddingVertical:6,
    borderRadius: 20,
    flexDirection: 'row',
    buttonColor: 'pink'
  },
  frase: {
    marginTop: 1,
    fontSize: 16,
    fontStyle: 'italic',
    marginVertical: 15,
    color: '#555'
  },
  erroText: {
    color: 'red',
    fontSize: 14,
    marginTop: 8,
    marginBottom: 4,
    textAlign: 'center'
  }
})

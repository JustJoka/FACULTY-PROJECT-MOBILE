import { Text, View, Image, FlatList } from 'react-native';
import { useState, useContext } from 'react'
import { Button, TextInput } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItemList } from '@react-navigation/drawer';
import AdminScreen from './admin';
import { ItemContext }  from './ItemContext'
import styles from './styles';



function LojaHome ({ navigation }) { {/* Função da tela da Loja */}

  const { itens } = useContext(ItemContext);
  return (
    <View style={styles.container}> {/* Container da página da Loja  */}
      <Text style={styles.titulo}>Bem-vindo à loja!</Text>
      
      {itens.length === 0  ? (
        <Text style={{marginTop: 20, fontSize: 18 }}>
          Nenhum produto disponível.
        </Text>
      ) : (
        <FlatList
          data={itens}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{marginTop: 20, alignItems: 'center' }}
          renderItem={({ item }) => (
            <View
              style={{
                backgroundColor: '#FFF3F8',
                borderRadius: 10,
                padding: 10,
                marginBottom: 10,
                alignItems: 'center',
                width: 250,
              }}
            >
              <Image
                source={{ uri: item.imagem }}
                style={{ 
                  width: 220,
                    height: 160,
                    borderRadius: 15,
                    marginBottom: 8,
                    resizeMode: 'cover',
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.25,
                    shadowRadius: 3.84,
                    elevation: 5,
                 }}
              />
              <Text style={{ fontWeight: 'bold', fontSize: 18 }}>{item.nome}</Text>
              <Text>R$ {item.preco}</Text>
              <Text>Status: {item.status}</Text>
            </View>
          )}
        />
      )}
    </View>
  );
}

function RelatorioScreen() {
  return (
    <View style={styles.container}> {/* Container da página da Loja  */}
      <Text style={styles.titulo}>Relatórios</Text>
    </View>
  );
}

function VendasScreen() {
  return(
    <View style={styles.container}> {/* Container da página da Loja  */}
      <Text style={styles.titulo}>Vendas</Text>
    </View>
  );
}


const Drawer = createDrawerNavigator();


export default function LojaScreen() {
  return (
    <Drawer.Navigator
      screenOptions={{
        headerStyle: {backgroundColor: '#6200ee'},
        headerTintColor: '#FACFF1',
        drawerStyle: {backgroundColor: '#FFE6F0', width: 220},
        drawerActiveTintColor: '#6200ee',
        drawerLabelStyle: {fontSize: 16}
    }}

    drawerContent={(props) => (
      <DrawerContentScrollView {...props} contentContainerStyle={{ flex:1 }}>
        <DrawerItemList {...props} />

        <View style={{flex: 1 }} />

        <View style={{ padding: 16 }}>
          <Button
            mode='contained'
            buttonColor='#6200ee'
            style={styles.botaoMenu}
            onPress={() => props.navigation.navigate('Login')}
          >
          Sair
          </Button>
        </View>
      </DrawerContentScrollView>
    )}
  >
      
    <Drawer.Screen name="Loja" component={LojaHome} />
  </Drawer.Navigator> 
  );
}

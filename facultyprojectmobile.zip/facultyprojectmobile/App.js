import { StyleSheet, Text, View } from 'react-native';
import * as React from 'react'
import { Button, TextInput } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import styles from './styles';

function CadastroScreen ({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Cadastrar</Text>

      <TextInput
        placeholder='Usuário'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
      />

      <TextInput
        placeholder='Email'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
      />

      <TextInput
        placeholder='Senha'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
      />

      <TextInput
        placeholder='Confirmar senha'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
      />

      <Button  mode='contained' onPress={() => navigation.navigate('Login')}>
      Criar conta {/*Titulo do botão*/}
      </Button>
    </View>
  );
}


function LoginScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Login</Text>
      <TextInput
        placeholder='Usuário'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
      />

      <TextInput
        placeholder='Senha'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
      />

      <Button style={styles.botoes} mode='contained' onPress={() => navigation.navigate('')}>
      Logar {/*Titulo do botão*/}
      </Button>

      <Text style={styles.frase}>Não possui uma conta ? Cadastre-se!</Text>
      <Button style={styles.botoes} mode='contained' onPress={() => navigation.navigate('Cadastro')}>
      Cadastre-se {/*Titulo do botão*/}
      </Button>
    </View>
  );
}
  
const Stack = createNativeStackNavigator();

export default function App() {
  return (
      <NavigationContainer>
        <Stack.Navigator screenOptions={{headerShown: false}} initialRouteName='Login'>
          <Stack.Screen name='Login' component={LoginScreen}/>
          <Stack.Screen name='Cadastro' component={CadastroScreen}/>
        </Stack.Navigator>
      </NavigationContainer>
  );
}



import { Text, View } from 'react-native';
import { Button } from 'react-native-paper';
import styles from './styles';

export default function AdminScreen ({ navigation }) {
  <View style={styles.container}>
    <Text style={styles.titulo}>Admin</Text>

  <Button style={styles.botoes}
  mode='contained'
  onPress={() => navigation.navigate('Login')}>
  </Button>
  </View>
}
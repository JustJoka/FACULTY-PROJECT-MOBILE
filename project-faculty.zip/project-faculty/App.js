import { Text, View } from 'react-native';
import { useState } from 'react'
import { Button, TextInput } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AdminScreen from './admin';
import styles from './styles';


function LojaScreen ({ navigation }) { {/* Função da tela da Loja */}
  return (
    <View style={styles.container}> {/* Container da página da Loja  */}
      <Text style={styles.titulo}>Bem-vindo à loja!</Text>
      <Text style={styles.titulo}>Coloque os itens aqui (apagar depois de colocar)</Text> {/* Apagar depois de colocar os itens */}
    </View>
  );
}



function CadastroScreen ({ navigation }) { {/* Função da tela de cadastro */}

  const [ usuario, setUsuario] = useState('');
  const [ email, setEmail ] = useState('');
  const [ senha, setSenha] = useState('');  {/* Variáveis de estados */}
  const [ confirmarSenha, setConfirmarSenha ] = useState('');
  const [ errorMessage, setErrorMessage] = useState('');

  const cadastrarUsuario = () => {
    
    setErrorMessage('')

    if ( !usuario.trim() || !email.trim() || !senha.trim() || !confirmarSenha.trim()) { {/* Verificando se todos os inputs estão preenchidos */}
      setErrorMessage('Por favor, preencha todos os campos corretamente!'); {/* Retorna mensagem de erro caso não estejam preenchidos */}
      return;

  }
    if ( senha !== confirmarSenha ) { {/* Verificando se as senhas são diferentes */}
      setErrorMessage('As senhas não coindicem!'); {/* Retorna mensagem de erro caso sejam diferentes */}
      return;
  }

    navigation.navigate('Login'); {/* Manda de volta para a página de Login */}
};

  return (
    <View style={styles.container}> {/* Container da página de Cadastro */}
      <Text style={styles.titulo}>Cadastrar</Text> {/* Titulo da página */}


      {/* Input do usuário tela de cadastro */}
      <TextInput 
        placeholder='Usuário'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
        value={usuario}
        onChangeText={setUsuario}
      />

      {/* Input do Email da tela de cadastro */}
      <TextInput
        placeholder='Email'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
        value={email}
        onChangeText={setEmail}
      />

      {/* Input da senha da tela de cadastro */}
      <TextInput
        placeholder='Senha'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      {/* Input confirmar senha da tela de cadastro */}
      <TextInput
        placeholder='Confirmar senha'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
        secureTextEntry
        value={confirmarSenha}
        onChangeText={setConfirmarSenha}
      />

      {/* Retorna uma mensagem de erro caso os campos não estejam preenchidos corretamente */}
      {errorMessage ? (
        <Text style={styles.erroText}>{errorMessage}</Text>
      ): null}

      <Button style={styles.botoes} mode='contained' onPress={cadastrarUsuario}> {/* Botão que ao cadastra o usuário e retorna para a tela de Login */}
      Criar conta {/*Titulo do botão*/}
      </Button>
    </View>
  );
}


function LoginScreen({ navigation }) { {/* Função da tela de Login */}


  const [ usuario, setUsuario] = useState('');
  const [ senha, setSenha] = useState('');  {/* Variáveis de estados */}
  const [ errorMessage, setErrorMessage] = useState('');

  const loginAdmin = () => {

    setErrorMessage('');

    if (!usuario.trim() || !senha.trim()) {  {/* Verificando se o usuário e senha estão preenchidos */}
      setErrorMessage('Por favor, preencha todos os campos corretamente!'); {/* Retorna mensagem de erro caso o usuário e senha não estiverem preenchidos */}
      return;
    }


    if ( usuario === 'admin' && senha === 'admin123'){  {/* Verificando o login do Admin */}
      navigation.navigate('Admin'); {/* Manda para a página do Admin caso logado como Admin */}
      return;
    } 
    if (usuario && senha) { {/* Verificando se o usuário e senha estão preenchidos */}
      navigation.navigate('Loja'); {/*  Caso logado manda para a página da loja */}
      return;
  }

    setErrorMessage('Usuário ou senha incorretos'); {/* Caso o login não existir, mostrará um erro! */}

  };
  

  return (
    <View style={styles.container}> {/* Container da página de Login */}
      <Text style={styles.titulo}>Login</Text> {/* Titulo da página */}

      {/* Input do usuário da tela de Login */}
      <TextInput
        placeholder='Usuário'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
        value={usuario}
        onChangeText={setUsuario}
      />

      {/* Input da senha da tela de Login */}
      <TextInput
        placeholder='Senha'
        style={styles.inputs}
        mode='outlined'
        outlineColor='transparent'
        activeOutlineColor='#6200ee'
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
      />

      {/* Mostrará o erro na tela caso o usuário esteja incorreto */}
      {errorMessage ? (
        <Text style={styles.erroText}>{errorMessage}</Text>
         ): null}

      <Button style={styles.botoes} mode='contained' onPress={loginAdmin}> {/* Botão que chama a tela do Admin */}
      Logar {/*Titulo do botão*/}
      </Button>

      <Text style={styles.frase}>Não possui uma conta ? Cadastre-se!</Text> {/* Mensagem ('Não possui uma conta ?') */}
      <Button style={styles.botoes} mode='contained' onPress={() => navigation.navigate('Cadastro')}>
      Cadastre-se {/*Titulo do botão*/}
      </Button>
    </View>
  );
}
  
const Stack = createNativeStackNavigator();

export default function App() {  {/* Input do usuário da tela de Login */}
  return (
      <NavigationContainer> {/* Controlador de telas do APP */}
        <Stack.Navigator screenOptions={{headerShown: false}} initialRouteName='Login'>
          <Stack.Screen name='Login' component={LoginScreen}/>
          <Stack.Screen name='Cadastro' component={CadastroScreen}/>
          <Stack.Screen name='Admin' component={AdminScreen}/>
          <Stack.Screen name='Loja' component={LojaScreen}/>
        </Stack.Navigator>
      </NavigationContainer>
  );
}

{/* Fim do APP */}


